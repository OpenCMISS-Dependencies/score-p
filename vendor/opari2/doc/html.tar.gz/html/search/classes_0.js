var searchData=
[
  ['opari2_5fregion_5finfo',['OPARI2_Region_info',['../structOPARI2__Region__info.html',1,'']]]
];
