var searchData=
[
  ['memory_20pooling_20for_20otf2',['Memory pooling for OTF2',['../group__callbacks__memory.html',1,'']]],
  ['metricref',['metricRef',['../unionOTF2__AttributeValue.html#a47c3f0539ddb8a0caf955ebdaf63429b',1,'OTF2_AttributeValue']]]
];
