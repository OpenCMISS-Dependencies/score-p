var searchData=
[
  ['delta_5ft',['delta_t',['../structSCOREP__Metric__Plugin__Info.html#a44a2ab20307bb9f44c986772df922c6f',1,'SCOREP_Metric_Plugin_Info']]],
  ['description',['description',['../structSCOREP__Metric__Plugin__MetricProperties.html#a9b1e96a0ae6c5a6d45da057ce2cbde3e',1,'SCOREP_Metric_Plugin_MetricProperties::description()'],['../structSCOREP__Metric__Properties.html#adf3a2f5393a286e208a400d464cbec8e',1,'SCOREP_Metric_Properties::description()']]]
];
