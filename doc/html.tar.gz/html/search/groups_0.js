var searchData=
[
  ['score_2dp_20user_20adapter',['Score-P User Adapter',['../group__SCOREP__User.html',1,'']]]
];
