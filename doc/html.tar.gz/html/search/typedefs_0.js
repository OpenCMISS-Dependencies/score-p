var searchData=
[
  ['scorep_5fuser_5fmetrictype',['SCOREP_User_MetricType',['../SCOREP__User__Types_8h.html#a256f8f899fe697e970f6b785c17c7914',1,'SCOREP_User_Types.h']]],
  ['scorep_5fuser_5fparameterhandle',['SCOREP_User_ParameterHandle',['../SCOREP__User__Types_8h.html#aa00c20701de660fba257bdf3128b41cb',1,'SCOREP_User_Types.h']]],
  ['scorep_5fuser_5fregionhandle',['SCOREP_User_RegionHandle',['../SCOREP__User__Types_8h.html#a5456c4b230a64442e9280f47e2dac962',1,'SCOREP_User_Types.h']]],
  ['scorep_5fuser_5fregiontype',['SCOREP_User_RegionType',['../SCOREP__User__Types_8h.html#aeebec87dcfc82b990cb2164f36dd4f72',1,'SCOREP_User_Types.h']]]
];
