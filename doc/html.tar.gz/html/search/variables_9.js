var searchData=
[
  ['plugin_5fversion',['plugin_version',['../structSCOREP__Metric__Plugin__Info.html#a4f17bc4134f44442e43623bc7e587266',1,'SCOREP_Metric_Plugin_Info']]],
  ['profiling_5ftype',['profiling_type',['../structSCOREP__Metric__Properties.html#af4ce9e42e171a4d80802e6f03659c14b',1,'SCOREP_Metric_Properties']]]
];
