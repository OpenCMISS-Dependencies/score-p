var searchData=
[
  ['scorep_5fmetric_5fplugin_5fentry',['SCOREP_METRIC_PLUGIN_ENTRY',['../SCOREP__MetricPlugins_8h.html#a6107d9468ac980a94ad707bd40a40e40',1,'SCOREP_MetricPlugins.h']]],
  ['scorep_5fmetric_5fplugin_5fversion',['SCOREP_METRIC_PLUGIN_VERSION',['../SCOREP__MetricPlugins_8h.html#a19947f3f006b54f239f9131e32191392',1,'SCOREP_MetricPlugins.h']]],
  ['scorep_5fuser_5finvalid_5fparameter',['SCOREP_USER_INVALID_PARAMETER',['../SCOREP__User__Types_8h.html#a8255dceb835519d1a95b5812d99be9c2',1,'SCOREP_User_Types.h']]],
  ['scorep_5fuser_5finvalid_5fregion',['SCOREP_USER_INVALID_REGION',['../SCOREP__User__Types_8h.html#a46062b8aeffded08e6eb63d9d70d734b',1,'SCOREP_User_Types.h']]]
];
