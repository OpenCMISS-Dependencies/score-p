var searchData=
[
  ['set_5fclock_5ffunction',['set_clock_function',['../structSCOREP__Metric__Plugin__Info.html#ac9ad0f2a8f6d1e1e987ed43d3db5f9a6',1,'SCOREP_Metric_Plugin_Info']]],
  ['source_5ftype',['source_type',['../structSCOREP__Metric__Properties.html#aed9d787efc1e2e2ab54c75b67bbbf966',1,'SCOREP_Metric_Properties']]],
  ['sync',['sync',['../structSCOREP__Metric__Plugin__Info.html#ae0ce349e670408edd2d6b827eb651d98',1,'SCOREP_Metric_Plugin_Info']]],
  ['synchronize',['synchronize',['../structSCOREP__Metric__Plugin__Info.html#a3e7baaaacd022944211dcfe716c9395a',1,'SCOREP_Metric_Plugin_Info']]]
];
