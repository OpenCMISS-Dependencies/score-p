var searchData=
[
  ['getting_20started',['Getting Started',['../quickstart.html',1,'']]]
];
