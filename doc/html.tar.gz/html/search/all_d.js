var searchData=
[
  ['usage_20of_20scorep_2dscore',['Usage of scorep-score',['../score.html',1,'']]],
  ['unit',['unit',['../structSCOREP__Metric__Plugin__MetricProperties.html#ab2f211fce95a8b3ad2fa5781cdc44458',1,'SCOREP_Metric_Plugin_MetricProperties::unit()'],['../structSCOREP__Metric__Properties.html#a51e41e457b2ea4746467fd6eb42c19f6',1,'SCOREP_Metric_Properties::unit()']]]
];
