var searchData=
[
  ['add_5fcounter',['add_counter',['../structSCOREP__Metric__Plugin__Info.html#a772e897a7e8113b5c82792d8899f1d4c',1,'SCOREP_Metric_Plugin_Info']]],
  ['application_20instrumentation',['Application Instrumentation',['../instrumentation.html',1,'']]],
  ['application_20measurement',['Application Measurement',['../measurement.html',1,'']]],
  ['application_20sampling',['Application Sampling',['../sampling.html',1,'']]]
];
